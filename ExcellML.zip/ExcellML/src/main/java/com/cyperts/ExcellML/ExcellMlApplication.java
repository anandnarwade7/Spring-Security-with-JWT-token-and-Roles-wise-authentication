package com.cyperts.ExcellML;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcellMlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcellMlApplication.class, args);
	}

}
