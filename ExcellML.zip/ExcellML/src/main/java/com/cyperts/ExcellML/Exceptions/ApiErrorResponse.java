package com.cyperts.ExcellML.Exceptions;

public class ApiErrorResponse {

}
