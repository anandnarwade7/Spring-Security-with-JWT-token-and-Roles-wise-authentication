package com.cyperts.ExcellML;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcellMlApplicationTests {

	@Test
	void contextLoads() {
	}

}
